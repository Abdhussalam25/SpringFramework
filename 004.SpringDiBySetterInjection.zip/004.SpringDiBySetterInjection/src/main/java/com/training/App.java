package com.training;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import com.training.bean.Calculator;
/**
 *skchandel2009@gmail.com
 */
public class App 
{
    public static void main( String[] args )
    {
    	ApplicationContext context=new ClassPathXmlApplicationContext("SpringBean.xml");
        Calculator calc=(Calculator)context.getBean("calc1");
        System.out.println(calc.addNumbers());
        
        calc=(Calculator)context.getBean("calc2");
        System.out.println(calc.subNumbers());
    }
}
