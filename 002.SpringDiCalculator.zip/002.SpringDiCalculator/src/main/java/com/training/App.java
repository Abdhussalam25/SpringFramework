package com.training;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.training.bean.Calculator;

public class App 
{
    public static void main( String[] args )
    {
        ApplicationContext context=new ClassPathXmlApplicationContext("SpringBean.xml");
        Calculator calc=(Calculator)context.getBean("calc");
        int addResult=calc.add(12, 34);
        System.out.println("sum is:"+addResult);
        int subResult=calc.sub(48, 34);
        System.out.println("diff is:"+subResult);
    }
}
