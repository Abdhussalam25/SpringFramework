package com.training.bean;
public class Hello {
	public void sayHello() {
		System.out.println("Hello Everyone, You are welcome in spring programming..");
	}

}
